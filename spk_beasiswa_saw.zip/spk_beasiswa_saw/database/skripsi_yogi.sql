-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 01, 2020 at 01:34 
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skripsi_yogi`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif_saw`
--

CREATE TABLE `alternatif_saw` (
  `id_alternatif_saw` int(11) NOT NULL,
  `NIS` varchar(100) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `jeniskelamin` varchar(10) NOT NULL,
  `ttl` date NOT NULL,
  `TempatLahir` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `foto` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alternatif_saw`
--

INSERT INTO `alternatif_saw` (`id_alternatif_saw`, `NIS`, `nama`, `jeniskelamin`, `ttl`, `TempatLahir`, `alamat`, `telepon`, `foto`) VALUES
(1, '33900190', 'Dede Muhammad', 'Laki-laki', '2002-05-16', 'Tasikmalaya', 'Jl. Cilembang no 17 Tasikmalaya', '089656476234', 'blank.png'),
(2, '33900196', 'Fina Silviana', 'Perempuan', '2003-08-03', 'Tasikmalaya', 'Jl. Cigeureung no 30 Tasikmalaya', '082234567090', 'blank.png'),
(3, '33900185', 'Ferdiansyah Restu', 'Laki-laki', '2002-03-08', 'Tasikmalaya', 'Jl. Indihiang no 160 Tasikmalaya', '089602465341', 'blank.png'),
(4, '33900188', 'Dini Dwi Utami', 'Perempuan', '2003-05-22', 'Tasikmalaya', 'Jl. Panyingkiran no 280 Tasikmalaya', '085223654908', 'blank.png'),
(10, '33900194', 'Amira Tasya', 'Perempuan', '2003-09-22', 'Tasikmalaya', 'Jl. Paseh Tasikmalaya', '089536115132', 'blank.png');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_penilaian`
--

CREATE TABLE `hasil_penilaian` (
  `id_penilaian` int(11) NOT NULL,
  `id_alternatif_saw` int(11) DEFAULT NULL,
  `Akhlak` int(11) DEFAULT NULL,
  `Nilai_Raport` int(11) DEFAULT NULL,
  `Nilai_UN` int(11) DEFAULT NULL,
  `Kompetensi_Kejuruan` int(11) DEFAULT NULL,
  `Aktif_Organisasi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hasil_penilaian`
--

INSERT INTO `hasil_penilaian` (`id_penilaian`, `id_alternatif_saw`, `Akhlak`, `Nilai_Raport`, `Nilai_UN`, `Kompetensi_Kejuruan`, `Aktif_Organisasi`) VALUES
(12, 1, 39, 12, 18, 24, 33),
(13, 2, 40, 13, 18, 23, 33),
(14, 3, 39, 14, 17, 24, 33),
(15, 4, 39, 13, 17, 22, 35),
(16, 10, 40, 14, 17, 23, 34);

-- --------------------------------------------------------

--
-- Table structure for table `hasil_saw`
--

CREATE TABLE `hasil_saw` (
  `id_hasil_saw` int(11) NOT NULL,
  `id_alternatif_saw` int(11) DEFAULT NULL,
  `hasil_saw` float(10,2) DEFAULT NULL,
  `tgl` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kriteria_saw`
--

CREATE TABLE `kriteria_saw` (
  `id_kriteria_saw` int(11) NOT NULL,
  `kriteria_saw` varchar(32) DEFAULT NULL,
  `bobot` float(5,2) DEFAULT NULL,
  `type` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kriteria_saw`
--

INSERT INTO `kriteria_saw` (`id_kriteria_saw`, `kriteria_saw`, `bobot`, `type`) VALUES
(1, 'Akhlak', 0.40, 'Benefit'),
(2, 'Nilai_Raport', 0.30, 'Benefit'),
(3, 'Nilai_UN', 0.20, 'Benefit'),
(4, 'Kompetensi_Kejuruan', 0.05, 'Benefit'),
(6, 'Aktif_Organisasi', 0.05, 'Benefit');

-- --------------------------------------------------------

--
-- Table structure for table `riwayat_saw`
--

CREATE TABLE `riwayat_saw` (
  `id` int(11) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `nilai` float(10,2) NOT NULL,
  `tgl` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_kriteria_saw`
--

CREATE TABLE `sub_kriteria_saw` (
  `id_subkriteria_saw` int(11) NOT NULL,
  `id_kriteria_saw` int(11) NOT NULL,
  `subkriteria` varchar(255) NOT NULL,
  `nilai` float(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_kriteria_saw`
--

INSERT INTO `sub_kriteria_saw` (`id_subkriteria_saw`, `id_kriteria_saw`, `subkriteria`, `nilai`) VALUES
(10, 2, '0-30', 1.00),
(11, 2, '31-49', 2.00),
(12, 2, '50-74', 3.00),
(13, 2, '75-84', 4.00),
(14, 2, '85-100', 5.00),
(15, 3, '0-30', 1.00),
(16, 3, '31-49', 2.00),
(17, 3, '50-74', 3.00),
(18, 3, '75-84', 4.00),
(19, 3, '85-100', 5.00),
(20, 4, 'Sangat Kurang', 1.00),
(21, 4, 'Kurang', 2.00),
(22, 4, 'Cukup', 3.00),
(23, 4, 'Baik', 4.00),
(24, 4, 'Sangat Baik', 5.00),
(25, 5, 'Sangat Kurang', 1.00),
(26, 5, 'Kurang', 2.00),
(27, 5, 'Cukup', 3.00),
(28, 5, 'Baik', 4.00),
(29, 5, 'Sangat Baik', 5.00),
(31, 6, 'Sangat Kurang', 1.00),
(32, 6, 'Kurang', 2.00),
(33, 6, 'Cukup', 3.00),
(34, 6, 'Baik', 4.00),
(35, 6, 'Sangat Baik', 5.00),
(36, 1, 'Sangat Kurang', 1.00),
(37, 1, 'Kurang', 2.00),
(38, 1, 'Cukup', 3.00),
(39, 1, 'Baik', 4.00),
(40, 1, 'Sangat Baik', 5.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$YHaYRtUh5DypwQvNpDP0i.tdMQ5sHrdUqbSeG.OcK0jZHWIYI213a'),
(4, 'ssinz', '$2y$10$x0utYIcussH/tu8C.o0mSOqS5xrcOLF9nERIPEiKNrv2Zzno0S1Q.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif_saw`
--
ALTER TABLE `alternatif_saw`
  ADD PRIMARY KEY (`id_alternatif_saw`),
  ADD UNIQUE KEY `NIS` (`NIS`);

--
-- Indexes for table `hasil_penilaian`
--
ALTER TABLE `hasil_penilaian`
  ADD PRIMARY KEY (`id_penilaian`),
  ADD KEY `id_alternatif_saw` (`id_alternatif_saw`);

--
-- Indexes for table `hasil_saw`
--
ALTER TABLE `hasil_saw`
  ADD PRIMARY KEY (`id_hasil_saw`),
  ADD KEY `id_alternatif_saw` (`id_alternatif_saw`);

--
-- Indexes for table `kriteria_saw`
--
ALTER TABLE `kriteria_saw`
  ADD PRIMARY KEY (`id_kriteria_saw`);

--
-- Indexes for table `riwayat_saw`
--
ALTER TABLE `riwayat_saw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_kriteria_saw`
--
ALTER TABLE `sub_kriteria_saw`
  ADD PRIMARY KEY (`id_subkriteria_saw`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif_saw`
--
ALTER TABLE `alternatif_saw`
  MODIFY `id_alternatif_saw` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `hasil_penilaian`
--
ALTER TABLE `hasil_penilaian`
  MODIFY `id_penilaian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `hasil_saw`
--
ALTER TABLE `hasil_saw`
  MODIFY `id_hasil_saw` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `kriteria_saw`
--
ALTER TABLE `kriteria_saw`
  MODIFY `id_kriteria_saw` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `riwayat_saw`
--
ALTER TABLE `riwayat_saw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sub_kriteria_saw`
--
ALTER TABLE `sub_kriteria_saw`
  MODIFY `id_subkriteria_saw` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
