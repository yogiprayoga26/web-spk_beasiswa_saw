<?php
  session_start();

  if (!isset($_SESSION["login"])) {
    echo "<script>
          alert('Mohon login terlebih dahulu !');
          document.location.href = '../login.php';
        </script>
       ";
    exit;
  }
  include '../saw/db/db_config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Table V02</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
					<div class="table">

						<div class="row header">
							<div class="cell">No</div>
							<div class="cell">NIS</div>
							<div class="cell">Nama Siswa</div>
							<div class="cell">Jenis Kelamin</div>
							<div class="cell">Tanggal Lahir</div>
							<div class="cell">Tempat Lahir</div>
							<div class="cell">Alamat</div>
							<div class="cell">Telepon</div>
							<div class="cell">Foto</div>
							<div class="cell">Action</div>

						</div>
						<?php $no=1; foreach($db->select('*','alternatif_saw')->get() as $data): ?>
                            <tr>
						<div class="row">
							<div class="cell" data-title="No">
								<?= $no ?>
							</div>
							<div class="cell" data-title="NIS">
								<?= $data['NIS'];?>
							</div>
							<div class="cell" data-title="Nama Siswa">
								<?= $data['nama']?>
							</div>
							<div class="cell" data-title="Jenis Kelamin">
								<?= $data['jeniskelamin']?>
							</div>
							<div class="cell" data-title="Tanggal Lahir">
								<?= $data['ttl']?>
							</div>
							<div class="cell" data-title="Tempat Lahir">
								<?= $data['TempatLahir']?>
							</div>
							<div class="cell" data-title="Alamat">
								<?= $data['alamat']?>
							</div>
							<div class="cell" data-title="Telepon">
								<?= $data['telepon']?>
							</div>
							<div class="cell" data-title="Foto">
								<?php if($data['foto'] != ""): ?>
                                        <img src="../saw/img/foto_siswa/<?php echo $data['foto']; ?>" class="img-thumbnail" width="75px" height="70px">
                                        <?php else: ?>
                                        <img src="../saw/img/foto_siswa/image_not_available.jpg" class="img-thumbnail" width="75px" height="70px">
                                    <?php endif; ?>
							</div>
							<div class="cell" data-title="Action">
								<a class="btn btn-warning" href="edit_alternatif.php?id=<?php echo $data[0]?>">Edit</a>
                                <a class="btn btn-danger"  onclick="return confirm('Yakin Hapus?')" href="delete_alternatif.php?id=<?php echo $data[0]?>">Hapus</a>
							</div>
						</div>
						<?php $no++; endforeach; ?>
					</div>
			</div>
		</div>
	</div>


	

<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>