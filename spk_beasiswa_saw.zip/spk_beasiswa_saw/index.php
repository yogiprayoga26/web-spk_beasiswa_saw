<script type="text/javascript">
	window.location.href="login.php"
</script>