<?php
	include 'saw/db/db_config.php';
	$id = $_GET['id'];
	if($db->delete('alternatif_saw')->where('id_alternatif_saw='.$id)->count() == 1){
		header('location:alternatif.php');
	} else {
		header('location:alternatif.php?error_msg=error_delete');
	}
?>