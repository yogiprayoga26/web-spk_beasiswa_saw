<?php
  session_start();

  if (!isset($_SESSION["login"])) {
    echo "<script>
          alert('Mohon login terlebih dahulu !');
          document.location.href = '../login.php';
        </script>
       ";
    exit;
  }
  
  include('../config.php');
  include('../fungsi.php');
?>
<link rel="stylesheet" href="plugin/menu.css">
 <div class="container">
 <h1>
    <a href="#menu">SPK Beasiswa</a>
 </h1>
    
<div class="popover" id="menu">
 <div class = 'content'>
  <a href="#" class="close"></a>
   <div class = 'nav'>
    <ul class = 'nav_list'>
      
    <div class = 'nav_list_item'>
	  <li><a href="../saw">SPK Beasiswa</a></li>
      </div>
    <div class = 'nav_list_item'>
	  <li><a href="../user.php">Data User</a></li>
      </div>
     <div class = 'nav_list_item'>
		<li><a href="../logout.php">Logout</a></li>
      </div>
      
	</ul>
  </div>
 </div>
 </div>
 </div>